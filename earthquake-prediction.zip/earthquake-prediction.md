```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import folium
from folium.plugins import MarkerCluster
from sklearn.cluster import KMeans, DBSCAN
```


```python
import os

print("Current working directory:", os.getcwd())
print("Files and folders here:", os.listdir())

# If you see 'earthquake_data' folder, list inside it:
if "earthquake_data" in os.listdir():
    print("Inside earthquake_data:", os.listdir("earthquake_data"))

```


```python
df1 = pd.read_csv("C:\\Users\\h\\Downloads\\archive (1)\\earthquake_1995-2023.csv")
df2 = pd.read_csv(r"C:\Users\h\Downloads\archive (1)\earthquake_data.csv")
```


```python
# 1. Inspect structure
# ----------------------------
print("Dataset 1 shape:", df1.shape)
print("Dataset 2 shape:", df2.shape)
print("\nDataset 1 info:")
print(df1.info())
print("\nDataset 2 info:")
print(df2.info())
```

    Dataset 1 shape: (1000, 19)
    Dataset 2 shape: (782, 19)
    
    Dataset 1 info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1000 entries, 0 to 999
    Data columns (total 19 columns):
     #   Column     Non-Null Count  Dtype  
    ---  ------     --------------  -----  
     0   title      1000 non-null   object 
     1   magnitude  1000 non-null   float64
     2   date_time  1000 non-null   object 
     3   cdi        1000 non-null   int64  
     4   mmi        1000 non-null   int64  
     5   alert      449 non-null    object 
     6   tsunami    1000 non-null   int64  
     7   sig        1000 non-null   int64  
     8   net        1000 non-null   object 
     9   nst        1000 non-null   int64  
     10  dmin       1000 non-null   float64
     11  gap        1000 non-null   float64
     12  magType    1000 non-null   object 
     13  depth      1000 non-null   float64
     14  latitude   1000 non-null   float64
     15  longitude  1000 non-null   float64
     16  location   994 non-null    object 
     17  continent  284 non-null    object 
     18  country    651 non-null    object 
    dtypes: float64(6), int64(5), object(8)
    memory usage: 148.6+ KB
    None
    
    Dataset 2 info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 782 entries, 0 to 781
    Data columns (total 19 columns):
     #   Column     Non-Null Count  Dtype  
    ---  ------     --------------  -----  
     0   title      782 non-null    object 
     1   magnitude  782 non-null    float64
     2   date_time  782 non-null    object 
     3   cdi        782 non-null    int64  
     4   mmi        782 non-null    int64  
     5   alert      415 non-null    object 
     6   tsunami    782 non-null    int64  
     7   sig        782 non-null    int64  
     8   net        782 non-null    object 
     9   nst        782 non-null    int64  
     10  dmin       782 non-null    float64
     11  gap        782 non-null    float64
     12  magType    782 non-null    object 
     13  depth      782 non-null    float64
     14  latitude   782 non-null    float64
     15  longitude  782 non-null    float64
     16  location   777 non-null    object 
     17  continent  206 non-null    object 
     18  country    484 non-null    object 
    dtypes: float64(6), int64(5), object(8)
    memory usage: 116.2+ KB
    None
    


```python
# 2. Missing values & duplicates
# ----------------------------
print("\nMissing values in Dataset 1:\n", df1.isnull().sum())
print("\nMissing values in Dataset 2:\n", df2.isnull().sum())
print("\nDuplicates in Dataset 1:", df1.duplicated().sum())
print("Duplicates in Dataset 2:", df2.duplicated().sum())
```

    
    Missing values in Dataset 1:
     title          0
    magnitude      0
    date_time      0
    cdi            0
    mmi            0
    alert        551
    tsunami        0
    sig            0
    net            0
    nst            0
    dmin           0
    gap            0
    magType        0
    depth          0
    latitude       0
    longitude      0
    location       6
    continent    716
    country      349
    dtype: int64
    
    Missing values in Dataset 2:
     title          0
    magnitude      0
    date_time      0
    cdi            0
    mmi            0
    alert        367
    tsunami        0
    sig            0
    net            0
    nst            0
    dmin           0
    gap            0
    magType        0
    depth          0
    latitude       0
    longitude      0
    location       5
    continent    576
    country      298
    dtype: int64
    
    Duplicates in Dataset 1: 0
    Duplicates in Dataset 2: 0
    


```python
# 3. Summary statistics
# ----------------------------
print("\nSummary Statistics (Dataset 1):")
print(df1.describe(include='all'))
print("\nSummary Statistics (Dataset 2):")
print(df2.describe(include='all'))
```

    
    Summary Statistics (Dataset 1):
                                            title    magnitude         date_time  \
    count                                    1000  1000.000000              1000   
    unique                                    984          NaN               990   
    top     M 6.5 - Kermadec Islands, New Zealand          NaN  11-01-2022 12:39   
    freq                                        3          NaN                 3   
    mean                                      NaN     6.940150               NaN   
    std                                       NaN     0.438148               NaN   
    min                                       NaN     6.500000               NaN   
    25%                                       NaN     6.600000               NaN   
    50%                                       NaN     6.800000               NaN   
    75%                                       NaN     7.100000               NaN   
    max                                       NaN     9.100000               NaN   
    
                    cdi         mmi  alert      tsunami          sig   net  \
    count   1000.000000  1000.00000    449  1000.000000  1000.000000  1000   
    unique          NaN         NaN      4          NaN          NaN    11   
    top             NaN         NaN  green          NaN          NaN    us   
    freq            NaN         NaN    353          NaN          NaN   960   
    mean       3.605000     6.02700    NaN     0.325000   847.915000   NaN   
    std        3.328972     1.43399    NaN     0.468609   301.802632   NaN   
    min        0.000000     1.00000    NaN     0.000000   650.000000   NaN   
    25%        0.000000     5.00000    NaN     0.000000   691.000000   NaN   
    50%        4.000000     6.00000    NaN     0.000000   744.000000   NaN   
    75%        7.000000     7.00000    NaN     1.000000   874.250000   NaN   
    max        9.000000    10.00000    NaN     1.000000  2910.000000   NaN   
    
                    nst         dmin          gap magType        depth  \
    count   1000.000000  1000.000000  1000.000000    1000  1000.000000   
    unique          NaN          NaN          NaN       9          NaN   
    top             NaN          NaN          NaN     mww          NaN   
    freq            NaN          NaN          NaN     502          NaN   
    mean     193.918000     1.125174    20.926290     NaN    74.612541   
    std      239.045858     2.073164    24.415895     NaN   130.812590   
    min        0.000000     0.000000     0.000000     NaN     2.700000   
    25%        0.000000     0.000000     0.000000     NaN    16.000000   
    50%        0.000000     0.000000    18.000000     NaN    29.000000   
    75%      403.000000     1.549250    27.000000     NaN    55.000000   
    max      934.000000    17.654000   239.000000     NaN   670.810000   
    
               latitude    longitude                  location continent  \
    count   1000.000000  1000.000000                       994       284   
    unique          NaN          NaN                       502         6   
    top             NaN          NaN  Kokopo, Papua New Guinea      Asia   
    freq            NaN          NaN                        29       137   
    mean       4.315554    51.486576                       NaN       NaN   
    std       26.633320   117.478302                       NaN       NaN   
    min      -61.848400  -179.968000                       NaN       NaN   
    25%      -13.518500   -71.694450                       NaN       NaN   
    50%       -2.443500   107.791000                       NaN       NaN   
    75%       25.167250   148.364750                       NaN       NaN   
    max       71.631200   179.662000                       NaN       NaN   
    
              country  
    count         651  
    unique         56  
    top     Indonesia  
    freq          140  
    mean          NaN  
    std           NaN  
    min           NaN  
    25%           NaN  
    50%           NaN  
    75%           NaN  
    max           NaN  
    
    Summary Statistics (Dataset 2):
               title   magnitude         date_time         cdi         mmi  alert  \
    count        782  782.000000               782  782.000000  782.000000    415   
    unique       768         NaN               773         NaN         NaN      4   
    top     M 6.9 -          NaN  11-01-2022 11:35         NaN         NaN  green   
    freq           3         NaN                 3         NaN         NaN    325   
    mean         NaN    6.941125               NaN    4.333760    5.964194    NaN   
    std          NaN    0.445514               NaN    3.169939    1.462724    NaN   
    min          NaN    6.500000               NaN    0.000000    1.000000    NaN   
    25%          NaN    6.600000               NaN    0.000000    5.000000    NaN   
    50%          NaN    6.800000               NaN    5.000000    6.000000    NaN   
    75%          NaN    7.100000               NaN    7.000000    7.000000    NaN   
    max          NaN    9.100000               NaN    9.000000    9.000000    NaN   
    
               tsunami          sig  net         nst        dmin         gap  \
    count   782.000000   782.000000  782  782.000000  782.000000  782.000000   
    unique         NaN          NaN   11         NaN         NaN         NaN   
    top            NaN          NaN   us         NaN         NaN         NaN   
    freq           NaN          NaN  747         NaN         NaN         NaN   
    mean      0.388747   870.108696  NaN  230.250639    1.325757   25.038990   
    std       0.487778   322.465367  NaN  250.188177    2.218805   24.225067   
    min       0.000000   650.000000  NaN    0.000000    0.000000    0.000000   
    25%       0.000000   691.000000  NaN    0.000000    0.000000   14.625000   
    50%       0.000000   754.000000  NaN  140.000000    0.000000   20.000000   
    75%       1.000000   909.750000  NaN  445.000000    1.863000   30.000000   
    max       1.000000  2910.000000  NaN  934.000000   17.654000  239.000000   
    
           magType       depth    latitude   longitude                   location  \
    count      782  782.000000  782.000000  782.000000                        777   
    unique       9         NaN         NaN         NaN                        413   
    top        mww         NaN         NaN         NaN  Kirakira, Solomon Islands   
    freq       468         NaN         NaN         NaN                         17   
    mean       NaN   75.883199    3.538100   52.609199                        NaN   
    std        NaN  137.277078   27.303429  117.898886                        NaN   
    min        NaN    2.700000  -61.848400 -179.968000                        NaN   
    25%        NaN   14.000000  -14.595600  -71.668050                        NaN   
    50%        NaN   26.295000   -2.572500  109.426000                        NaN   
    75%        NaN   49.750000   24.654500  148.941000                        NaN   
    max        NaN  670.810000   71.631200  179.662000                        NaN   
    
           continent    country  
    count        206        484  
    unique         6         49  
    top         Asia  Indonesia  
    freq         100        110  
    mean         NaN        NaN  
    std          NaN        NaN  
    min          NaN        NaN  
    25%          NaN        NaN  
    50%          NaN        NaN  
    75%          NaN        NaN  
    max          NaN        NaN  
    


```python
# 4. Distributions of numerical variables
# ----------------------------
num_cols = [col for col in df1.columns if df1[col].dtype in [np.int64, np.float64]]

for col in num_cols:
    plt.figure(figsize=(8,4))
    sns.histplot(df1[col], kde=True, bins=50)
    plt.title(f"Distribution of {col}")
    plt.show()
```


    
![png](output_6_0.png)
    



    
![png](output_6_1.png)
    



    
![png](output_6_2.png)
    



    
![png](output_6_3.png)
    



    
![png](output_6_4.png)
    



    
![png](output_6_5.png)
    



    
![png](output_6_6.png)
    



    
![png](output_6_7.png)
    



    
![png](output_6_8.png)
    



    
![png](output_6_9.png)
    



    
![png](output_6_10.png)
    



```python
# 5. Time trends
# ----------------------------
if 'date' in df1.columns:
    df1['date'] = pd.to_datetime(df1['date'], errors='coerce')
    df1['year'] = df1['date'].dt.year
    df1['month'] = df1['date'].dt.month

    plt.figure(figsize=(12,6))
    df1.groupby('year').size().plot(kind='bar')
    plt.title("Number of Earthquakes per Year")
    plt.ylabel("Count")
    plt.show()

    plt.figure(figsize=(12,6))
    sns.boxplot(x='year', y='magnitude', data=df1)
    plt.title("Earthquake Magnitude Trends by Year")
    plt.xticks(rotation=90)
    plt.show()

```


```python
# ----------------------------
# 6. Geospatial visualization
# ----------------------------
if {'latitude', 'longitude'}.issubset(df1.columns):
    m = folium.Map(location=[0, 0], zoom_start=2)
    marker_cluster = MarkerCluster().add_to(m)
    
    for i, row in df1.sample(min(10000, len(df1))).iterrows():
        folium.Marker([row['latitude'], row['longitude']], 
                      popup=f"Magnitude: {row.get('magnitude', 'NA')} Depth: {row.get('depth', 'NA')}").add_to(marker_cluster)
    m.save("earthquake_map.html")
    print("Geospatial map saved as earthquake_map.html")

    # KMeans clustering
    coords = df1[['latitude', 'longitude']].dropna()
    kmeans = KMeans(n_clusters=5, n_init=10, random_state=42)
    coords['cluster'] = kmeans.fit_predict(coords)

    plt.figure(figsize=(8,6))
    sns.scatterplot(x='longitude', y='latitude', hue='cluster', data=coords, palette='tab10')
    plt.title("Earthquake Clusters (KMeans)")
    plt.show()

    # DBSCAN clustering
    dbscan = DBSCAN(eps=1.5, min_samples=50)
    coords['dbscan_cluster'] = dbscan.fit_predict(coords[['latitude','longitude']])

    plt.figure(figsize=(8,6))
    sns.scatterplot(x='longitude', y='latitude', hue='dbscan_cluster', data=coords, palette='tab20')
    plt.title("Earthquake Clusters (DBSCAN)")
    plt.show()
```

    Geospatial map saved as earthquake_map.html
    


    
![png](output_8_1.png)
    



    
![png](output_8_2.png)
    



```python
# ----------------------------
# 7. Correlation analysis
# ----------------------------
plt.figure(figsize=(10,6))
sns.heatmap(df1.corr(numeric_only=True), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()
```


    
![png](output_9_0.png)
    



```python

```
